/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Demo2;

/**
 *
 * @author sharma
 */
public class Demo3 {
    public int add(String i, String j)
    {
        int a=Integer.parseInt(i);
        int b=Integer.parseInt(j);
        return a+b;
    }
}
