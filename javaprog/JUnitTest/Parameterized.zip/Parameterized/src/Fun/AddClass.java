package Fun;

public class AddClass {
    public int add(String s1, String s2)
    {
        int i=Integer.parseInt(s1);
        int j=Integer.parseInt(s2);
        return i+j;
    }
}
