package param;

public class Param {
    public int add(int x, int y)
    {
        return x+y;
    }
}
